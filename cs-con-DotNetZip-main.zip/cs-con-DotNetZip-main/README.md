# cs-con-DotNetZip

## [DotNetZip - C# Examples](https://documentation.help/DotNetZip/CSharp.htm)

## [NuGet](https://www.nuget.org/packages/DotNetZip/)
```
dotnet add package DotNetZip --version 1.16.0
```
